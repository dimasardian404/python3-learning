import socket
from concurrent.futures import ThreadPoolExecutor

def scan_port(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            result = sock.connect_ex((host, port))
            if result == 0:
                print(f"Port {port}: Terbuka")
            return port, result == 0
    except Exception:
        return port, False

def port_scanner(host, start_port=1, end_port=100):
    print(f"Memindai {host}...")
    open_ports = []
    
    with ThreadPoolExecutor(max_workers=100) as executor:
        futures = [executor.submit(scan_port, host, port) 
                  for port in range(start_port, end_port + 1)]
        
        for future in futures:
            port, is_open = future.result()
            if is_open:
                open_ports.append(port)
    
    return open_ports

# Penggunaan
open_ports = port_scanner("103.166.122.70", 1, 1000)