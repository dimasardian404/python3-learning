#!/usr/bin/env python3
"""
Simple Port Scanner
Alat untuk memindai port pada host target dengan berbagai fitur
Author: Cybersecurity Tool
Version: 1.0.0
"""

import socket
import threading
import concurrent.futures
import argparse
import json
import time
import sys
from datetime import datetime
import os
from typing import List, Dict, Optional, Tuple

# ============================================================================
# KONFIGURASI DAN DATABASE
# ============================================================================

# Database layanan umum dan port default
SERVICE_DB = {
    7: "Echo",
    19: "Chargen",
    20: "FTP-Data",
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    26: "RSFTP",
    37: "Time",
    43: "WHOIS",
    49: "TACACS",
    53: "DNS",
    67: "DHCP-Server",
    68: "DHCP-Client",
    69: "TFTP",
    70: "Gopher",
    79: "Finger",
    80: "HTTP",
    88: "Kerberos",
    102: "ISO-TSAP",
    109: "POP2",
    110: "POP3",
    111: "RPCBind",
    113: "Ident",
    119: "NNTP",
    123: "NTP",
    135: "MSRPC",
    137: "NetBIOS-NS",
    138: "NetBIOS-DGM",
    139: "NetBIOS-SSN",
    143: "IMAP",
    161: "SNMP",
    162: "SNMP-Trap",
    177: "XDMCP",
    179: "BGP",
    194: "IRC",
    201: "AppleTalk",
    264: "BGMP",
    318: "TSP",
    381: "HP OpenView",
    382: "HP OpenView",
    383: "HP OpenView",
    389: "LDAP",
    411: "Direct Connect",
    412: "Direct Connect",
    443: "HTTPS",
    445: "SMB",
    464: "Kerberos",
    465: "SMTPS",
    497: "Dantz Retrospect",
    500: "ISAKMP",
    512: "Exec",
    513: "Login",
    514: "Shell",
    515: "Printer",
    520: "RIP",
    521: "RIPng",
    540: "UUCP",
    543: "Klogin",
    544: "Kshell",
    546: "DHCPv6-Client",
    547: "DHCPv6-Server",
    548: "AFP",
    554: "RTSP",
    563: "NNTP over SSL",
    587: "SMTP (Submission)",
    591: "FileMaker",
    593: "MSRPC over HTTPS",
    631: "IPP",
    636: "LDAPS",
    639: "MSDP",
    646: "LDP",
    691: "MS Exchange",
    860: "iSCSI",
    873: "rsync",
    902: "VMware Server",
    989: "FTPS-DATA",
    990: "FTPS",
    993: "IMAPS",
    995: "POP3S",
    1025: "Microsoft RPC",
    1026: "Windows Messenger",
    1029: "Microsoft Messenger",
    1080: "SOCKS Proxy",
    1194: "OpenVPN",
    1214: "Kazaa",
    1241: "Nessus",
    1311: "Dell OpenManage",
    1337: "Waste",
    1433: "MSSQL",
    1434: "MSSQL Monitor",
    1512: "WINS",
    1521: "Oracle DB",
    1723: "PPTP",
    1725: "Steam",
    1741: "CiscoWorks 2000",
    1755: "MS Media Server",
    1812: "RADIUS",
    1863: "MSN Messenger",
    1935: "Adobe Flash",
    1985: "Cisco HSRP",
    2000: "Cisco SCCP",
    2049: "NFS",
    2082: "cPanel",
    2083: "cPanel SSL",
    2100: "Oracle XDB",
    2222: "DirectAdmin",
    2302: "Halo",
    2483: "Oracle DB SSL",
    2484: "Oracle DB SSL",
    3000: "Node.js",
    3128: "Squid Proxy",
    3306: "MySQL",
    3389: "RDP",
    3396: "Novell NDPS",
    3689: "iTunes",
    3690: "SVN",
    3724: "World of Warcraft",
    3784: "Ventrilo",
    4333: "mSQL",
    4444: "Metasploit",
    4500: "IPSec NAT-T",
    4664: "Google Desktop",
    4672: "eMule",
    4899: "Radmin",
    5000: "UPnP",
    5001: "Synology",
    5004: "RTP",
    5005: "RTP",
    5050: "Yahoo Messenger",
    5060: "SIP",
    5190: "AIM/ICQ",
    5222: "XMPP",
    5223: "XMPP SSL",
    5432: "PostgreSQL",
    5500: "VNC",
    5631: "pcAnywhere",
    5632: "pcAnywhere",
    5800: "VNC over HTTP",
    5900: "VNC",
    5901: "VNC",
    6000: "X11",
    6001: "X11",
    6112: "Battle.net",
    6129: "DameWare",
    6257: "WinMX",
    6346: "Gnutella",
    6347: "Gnutella",
    6881: "BitTorrent",
    6969: "BitTorrent",
    7000: "Azureus",
    7001: "WebLogic",
    7002: "WebLogic SSL",
    7070: "RealServer",
    7547: "CWMP",
    8000: "HTTP Alternate",
    8008: "HTTP Alternate",
    8009: "AJP",
    8080: "HTTP Proxy",
    8081: "HTTP Proxy",
    8087: "Parallels Plesk",
    8118: "Privoxy",
    8200: "VMware Server",
    8222: "VMware Server",
    8291: "Winbox",
    8333: "Bitcoin",
    8443: "HTTPS Alternate",
    8500: "Adobe ColdFusion",
    8767: "TeamSpeak",
    8880: "HTTP Alternate",
    8888: "HTTP Alternate",
    9000: "SonarQube",
    9001: "Tor",
    9043: "WebSphere",
    9060: "WebSphere",
    9080: "WebSphere",
    9090: "WebSphere",
    9091: "Openfire Admin",
    9100: "Printer",
    9101: "Bacula",
    9102: "Bacula",
    9103: "Bacula",
    9119: "MXit",
    9150: "Tor",
    9300: "IBM Cognos",
    9418: "Git",
    9443: "VMware VSphere",
    9999: "Urchin",
    10000: "Webmin",
    10001: "Ubiquiti",
    10050: "Zabbix Agent",
    10051: "Zabbix Server",
    10161: "SNMP-Trap",
    11211: "Memcached",
    12345: "NetBus",
    13720: "NetBackup",
    13721: "NetBackup",
    14567: "Battlefield",
    15118: "Dipnet",
    19226: "AdminSecure",
    19638: "Ensim",
    20000: "Usermin",
    24800: "Synergy",
    25999: "Xfire",
    27015: "Steam",
    27017: "MongoDB",
    27018: "MongoDB",
    27374: "Sub7",
    27960: "Quake",
    31337: "Back Orifice",
    32768: "Filenet TMS",
    33434: "Traceroute",
    47808: "BACnet",
}

# Preset port untuk scanning cepat
PORT_PRESETS = {
    "common": [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3306, 3389, 5900],
    "web": [80, 443, 8080, 8443, 8000, 3000, 8008, 8081],
    "database": [1433, 1521, 3306, 5432, 27017, 6379, 9200],
    "windows": [135, 137, 138, 139, 445, 3389, 5985, 5986],
    "services": [21, 22, 23, 25, 53, 67, 68, 69, 80, 110, 123, 143, 161, 389, 443],
    "gaming": [27015, 27016, 25565, 7777, 27960, 28960],
    "all": list(range(1, 1025)),
    "custom": []
}

# ============================================================================
# FUNGSI UTILITAS
# ============================================================================

def print_banner():
    """Menampilkan banner aplikasi"""
    banner = """
    ╔══════════════════════════════════════════════════════════╗
    ║              SIMPLE PORT SCANNER v1.0.0                  ║
    ║              Cybersecurity Tool - Python                 ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_privileges():
    """Cek apakah program punya privileges yang cukup"""
    try:
        if os.name == 'posix':
            if os.geteuid() != 0:
                print("[!] Warning: Running without root privileges.")
                print("    Some scan types may not work correctly.")
                return False
            return True
        elif os.name == 'nt':
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
            if not is_admin:
                print("[!] Warning: Running without administrator privileges.")
                print("    Some scan types may not work correctly.")
                return False
            return True
    except:
        pass
    return True

def parse_port_range(port_arg: str) -> List[int]:
    """Parse port range dari string input"""
    ports = []
    
    try:
        if '-' in port_arg:
            # Format: start-end
            start, end = map(int, port_arg.split('-'))
            if start < 1 or end > 65535 or start > end:
                raise ValueError("Port range tidak valid")
            ports = list(range(start, end + 1))
        elif ',' in port_arg:
            # Format: port1,port2,port3
            ports = [int(p.strip()) for p in port_arg.split(',')]
            if any(p < 1 or p > 65535 for p in ports):
                raise ValueError("Port number tidak valid")
        else:
            # Format: single port
            port = int(port_arg)
            if port < 1 or port > 65535:
                raise ValueError("Port number tidak valid")
            ports = [port]
    except ValueError as e:
        print(f"[!] Error parsing ports: {e}")
        sys.exit(1)
    
    return ports

def resolve_hostname(hostname: str) -> str:
    """Resolve hostname ke IP address"""
    try:
        ip_address = socket.gethostbyname(hostname)
        return ip_address
    except socket.gaierror:
        print(f"[!] Tidak dapat resolve hostname: {hostname}")
        return hostname

# ============================================================================
# FUNGSI SCANNING
# ============================================================================

def scan_port_tcp(host: str, port: int, timeout: float = 1.0) -> Tuple[int, bool, Optional[str]]:
    """
    Scan single port menggunakan TCP Connect
    Returns: (port, is_open, banner)
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            
            if result == 0:
                # Port terbuka, coba dapatkan banner
                banner = None
                try:
                    # Kirim dummy data untuk trigger response
                    sock.send(b"GET / HTTP/1.0\r\n\r\n")
                    banner = sock.recv(1024).decode('utf-8', errors='ignore').strip()
                    # Ambil hanya baris pertama jika panjang
                    if len(banner) > 100:
                        banner = banner[:100] + "..."
                except:
                    banner = None
                
                return (port, True, banner)
            else:
                return (port, False, None)
    except socket.timeout:
        return (port, False, None)
    except Exception as e:
        # print(f"[!] Error scanning port {port}: {e}")  # Debug mode only
        return (port, False, None)

def scan_port_udp(host: str, port: int, timeout: float = 2.0) -> Tuple[int, bool]:
    """
    Scan single port menggunakan UDP (basic)
    Note: UDP scanning tidak akurat karena connectionless
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout)
            
            # Kirim data dummy ke port
            message = b"ping"
            sock.sendto(message, (host, port))
            
            try:
                # Coba terima response
                data, addr = sock.recvfrom(1024)
                # Jika dapat response, port mungkin terbuka
                return (port, True)
            except socket.timeout:
                # Timeout bisa berarti port terbuka atau terfilter
                return (port, False)
    except Exception:
        return (port, False)

def threaded_port_scan(
    host: str, 
    ports: List[int], 
    max_threads: int = 100, 
    timeout: float = 1.0,
    protocol: str = 'tcp',
    show_closed: bool = False
) -> Dict[int, Dict]:
    """
    Scan multiple ports dengan multi-threading
    Returns: Dictionary dengan hasil scan
    """
    print(f"[*] Memulai scan pada {host}")
    print(f"[*] Protocol: {protocol.upper()}")
    print(f"[*] Ports: {len(ports)} ports")
    print(f"[*] Threads: {max_threads}")
    print(f"[*] Timeout: {timeout} detik")
    print("-" * 60)
    
    results = {}
    lock = threading.Lock()
    scanned_ports = 0
    open_ports = 0
    
    def update_progress():
        """Update progress bar"""
        with lock:
            nonlocal scanned_ports
            scanned_ports += 1
            percentage = (scanned_ports / len(ports)) * 100
            progress = int(percentage / 2)  # 50 karakter untuk 100%
            progress_bar = f"[{'#' * progress}{'.' * (50 - progress)}]"
            sys.stdout.write(f"\r[*] Scanning: {progress_bar} {percentage:.1f}% ({scanned_ports}/{len(ports)})")
            sys.stdout.flush()
    
    def scan_wrapper(port: int):
        """Wrapper untuk scan function dengan progress update"""
        if protocol.lower() == 'udp':
            port_result, is_open = scan_port_udp(host, port, timeout)
            banner = None
        else:
            port_result, is_open, banner = scan_port_tcp(host, port, timeout)
        
        service = SERVICE_DB.get(port, "Unknown")
        
        with lock:
            if is_open:
                nonlocal open_ports
                open_ports += 1
                status = "OPEN"
                print(f"\n[+] Port {port:5}/tcp {status:8} {service:20} {banner if banner else ''}")
            elif show_closed:
                status = "CLOSED"
                print(f"\n[-] Port {port:5}/tcp {status:8} {service:20}")
            
            results[port] = {
                'port': port,
                'open': is_open,
                'service': service,
                'banner': banner,
                'protocol': protocol
            }
        
        update_progress()
        return (port, is_open, banner)
    
    # Setup progress display
    print("[*] Initializing scanner...")
    
    # Eksekusi scan dengan thread pool
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
            # Submit semua tasks
            futures = [executor.submit(scan_wrapper, port) for port in ports]
            
            # Tunggu semua tasks selesai
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result(timeout=timeout + 2)
                except concurrent.futures.TimeoutError:
                    pass
                except Exception as e:
                    print(f"\n[!] Error: {e}")
    
    except KeyboardInterrupt:
        print("\n\n[!] Scan dihentikan oleh user")
        return results
    
    print("\n" + "-" * 60)
    return results

def service_detection(host: str, port: int, timeout: float = 3.0) -> Optional[str]:
    """
    Deteksi layanan lebih detail dengan banner grabbing
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((host, port))
            
            # Coba dapatkan banner untuk service tertentu
            if port in [21, 22, 25, 80, 110, 143, 443]:
                try:
                    # Kirim probe berdasarkan port
                    if port == 22:  # SSH
                        sock.send(b"\n")
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    elif port == 80 or port == 443:  # HTTP/HTTPS
                        sock.send(b"HEAD / HTTP/1.0\r\n\r\n")
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    elif port == 21:  # FTP
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    elif port == 25:  # SMTP
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    elif port == 110:  # POP3
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    else:
                        banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    
                    return banner.strip()[:200]
                except:
                    return None
    except:
        return None
    
    return None

# ============================================================================
# REPORTING DAN OUTPUT
# ============================================================================

def generate_scan_report(
    host: str, 
    results: Dict[int, Dict], 
    scan_type: str = "TCP Connect",
    start_time: float = None,
    end_time: float = None
) -> Dict:
    """Generate laporan hasil scanning"""
    
    open_ports = [r for r in results.values() if r['open']]
    closed_ports = [r for r in results.values() if not r['open']]
    
    scan_duration = end_time - start_time if start_time and end_time else 0
    
    report = {
        "scan_info": {
            "target_host": host,
            "scan_type": scan_type,
            "start_time": datetime.fromtimestamp(start_time).isoformat() if start_time else None,
            "end_time": datetime.fromtimestamp(end_time).isoformat() if end_time else None,
            "duration_seconds": round(scan_duration, 2),
            "total_ports_scanned": len(results),
            "open_ports_count": len(open_ports),
            "closed_ports_count": len(closed_ports)
        },
        "open_ports": [],
        "vulnerability_checks": []
    }
    
    # Detail port terbuka
    for port_data in open_ports:
        port_info = {
            "port": port_data['port'],
            "protocol": port_data['protocol'],
            "service": port_data['service'],
            "banner": port_data['banner'],
            "status": "open"
        }
        report["open_ports"].append(port_info)
    
    # Basic vulnerability checks
    for port_data in open_ports:
        port = port_data['port']
        service = port_data['service'].lower()
        
        vuln_check = {
            "port": port,
            "service": service,
            "checks": []
        }
        
        # Common vulnerability checks
        if port == 21 and 'ftp' in service:
            vuln_check["checks"].append("FTP mungkin tanpa SSL/TLS")
        elif port == 23:
            vuln_check["checks"].append("Telnet tidak aman - gunakan SSH")
        elif port == 80 and 'http' in service:
            vuln_check["checks"].append("HTTP tanpa enkripsi - gunakan HTTPS")
        elif port == 137 or port == 138 or port == 139:
            vuln_check["checks"].append("NetBIOS mungkin exposed")
        elif port == 445:
            vuln_check["checks"].append("SMB port terbuka - periksa konfigurasi")
        elif port == 3389:
            vuln_check["checks"].append("RDP exposed - pertimbangkan VPN")
        elif port == 5900 or port == 5901:
            vuln_check["checks"].append("VNC exposed - gunakan SSH tunnel")
        
        if vuln_check["checks"]:
            report["vulnerability_checks"].append(vuln_check)
    
    return report

def print_summary_report(report: Dict):
    """Print summary report ke console"""
    print("\n" + "=" * 70)
    print("SCAN SUMMARY")
    print("=" * 70)
    
    info = report["scan_info"]
    print(f"Target Host     : {info['target_host']}")
    print(f"Scan Type       : {info['scan_type']}")
    print(f"Duration        : {info['duration_seconds']} seconds")
    print(f"Ports Scanned   : {info['total_ports_scanned']}")
    print(f"Open Ports      : {info['open_ports_count']}")
    print(f"Closed Ports    : {info['closed_ports_count']}")
    
    if info['open_ports_count'] > 0:
        print("\n" + "-" * 70)
        print("OPEN PORTS DETAIL")
        print("-" * 70)
        print(f"{'PORT':<8} {'PROTOCOL':<10} {'SERVICE':<20} {'BANNER':<30}")
        print("-" * 70)
        
        for port_info in report["open_ports"]:
            port = port_info["port"]
            protocol = port_info["protocol"].upper()
            service = port_info["service"]
            banner = port_info["banner"] or ""
            
            # Potong banner jika terlalu panjang
            if len(banner) > 30:
                banner = banner[:27] + "..."
            
            print(f"{port:<8} {protocol:<10} {service:<20} {banner:<30}")
    
    if report["vulnerability_checks"]:
        print("\n" + "-" * 70)
        print("SECURITY CHECKS")
        print("-" * 70)
        
        for vuln in report["vulnerability_checks"]:
            print(f"Port {vuln['port']} ({vuln['service']}):")
            for check in vuln["checks"]:
                print(f"  ⚠️  {check}")
    
    print("\n" + "=" * 70)
    print("SCAN COMPLETE")
    print("=" * 70)

def save_report(report: Dict, filename: str = None):
    """Simpan laporan ke file JSON"""
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        host_clean = report["scan_info"]["target_host"].replace('.', '_')
        filename = f"portscan_{host_clean}_{timestamp}.json"
    
    try:
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"[+] Laporan disimpan sebagai: {filename}")
        return filename
    except Exception as e:
        print(f"[!] Gagal menyimpan laporan: {e}")
        return None

def export_to_csv(report: Dict, filename: str = None):
    """Export hasil scan ke CSV"""
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        host_clean = report["scan_info"]["target_host"].replace('.', '_')
        filename = f"portscan_{host_clean}_{timestamp}.csv"
    
    try:
        import csv
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['Port', 'Protocol', 'Service', 'Status', 'Banner']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for port_info in report["open_ports"]:
                writer.writerow({
                    'Port': port_info['port'],
                    'Protocol': port_info['protocol'],
                    'Service': port_info['service'],
                    'Status': 'OPEN',
                    'Banner': port_info['banner'] or ''
                })
        
        print(f"[+] CSV exported: {filename}")
        return filename
    except ImportError:
        print("[!] CSV export requires csv module (built-in)")
        return None
    except Exception as e:
        print(f"[!] Gagal export CSV: {e}")
        return None

# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

def setup_argparse():
    """Setup command line arguments parser"""
    parser = argparse.ArgumentParser(
        description='Simple Port Scanner - Alat untuk memindai port pada host target',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Contoh Penggunaan:
  %(prog)s 192.168.1.1
  %(prog)s example.com -p 1-1000
  %(prog)s 10.0.0.1 --preset web -t 200
  %(prog)s localhost -p 80,443,22,21 --timeout 2
  %(prog)s target.com -p 1-500 --output scan_report.json
        """
    )
    
    # Required arguments
    parser.add_argument(
        'host',
        help='Target host (IP address atau domain)'
    )
    
    # Optional arguments
    parser.add_argument(
        '-p', '--ports',
        help='Port range (1-1000) atau list (80,443,22)',
        default='1-1000'
    )
    
    parser.add_argument(
        '--preset',
        choices=['common', 'web', 'database', 'windows', 'services', 'gaming', 'all'],
        help='Port preset untuk scanning cepat',
        default=None
    )
    
    parser.add_argument(
        '-t', '--threads',
        type=int,
        default=100,
        help='Jumlah threads untuk scanning (default: 100)'
    )
    
    parser.add_argument(
        '--timeout',
        type=float,
        default=1.0,
        help='Timeout untuk koneksi (detik) (default: 1.0)'
    )
    
    parser.add_argument(
        '--protocol',
        choices=['tcp', 'udp', 'both'],
        default='tcp',
        help='Protocol untuk scanning (default: tcp)'
    )
    
    parser.add_argument(
        '-o', '--output',
        help='File output untuk laporan (JSON format)'
    )
    
    parser.add_argument(
        '--csv',
        help='Export hasil ke file CSV'
    )
    
    parser.add_argument(
        '--show-closed',
        action='store_true',
        help='Tampilkan port yang tertutup'
    )
    
    parser.add_argument(
        '--no-banner',
        action='store_true',
        help='Nonaktifkan banner grabbing'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Mode verbose (debug output)'
    )
    
    return parser.parse_args()

# ============================================================================
# MAIN FUNCTION
# ============================================================================

def main():
    """Fungsi utama program"""
    
    # Parse arguments
    args = setup_argparse()
    
    # Tampilkan banner
    if not args.no_banner:
        print_banner()
    
    # Cek privileges
    check_privileges()
    
    # Resolve hostname ke IP
    target_ip = resolve_hostname(args.host)
    print(f"[*] Target: {args.host} ({target_ip})")
    
    # Tentukan port yang akan di-scan
    if args.preset:
        # Gunakan preset
        if args.preset == 'all':
            ports = list(range(1, 65536))
        else:
            ports = PORT_PRESETS[args.preset]
        print(f"[*] Menggunakan preset: {args.preset} ({len(ports)} ports)")
    else:
        # Parse port range dari argument
        ports = parse_port_range(args.ports)
        print(f"[*] Port range: {min(ports)}-{max(ports)} ({len(ports)} ports)")
    
    # Batasi jumlah port jika terlalu banyak
    if len(ports) > 10000 and not args.verbose:
        print(f"[!] Warning: Scanning {len(ports)} ports mungkin memakan waktu lama")
        confirm = input("[?] Lanjutkan? (y/N): ")
        if confirm.lower() != 'y':
            print("[*] Scan dibatalkan")
            sys.exit(0)
    
    # Waktu mulai
    start_time = time.time()
    
    # Eksekusi scan
    results = {}
    
    if args.protocol in ['tcp', 'both']:
        print(f"\n[*] Memulai TCP scan...")
        tcp_results = threaded_port_scan(
            target_ip,
            ports,
            max_threads=args.threads,
            timeout=args.timeout,
            protocol='tcp',
            show_closed=args.show_closed
        )
        results.update(tcp_results)
    
    if args.protocol in ['udp', 'both']:
        if args.protocol == 'both':
            print()  # Spasi antar protocol
        
        print(f"\n[*] Memulai UDP scan...")
        print("[!] Note: UDP scanning tidak akurat dan memakan waktu lama")
        
        # Untuk UDP, batasi port yang discan
        udp_ports = ports[:100] if len(ports) > 100 else ports  # Max 100 port untuk UDP
        if len(ports) > 100:
            print(f"[*] UDP scan dibatasi ke {len(udp_ports)} port pertama")
        
        udp_results = threaded_port_scan(
            target_ip,
            udp_ports,
            max_threads=min(args.threads, 50),  # Thread lebih sedikit untuk UDP
            timeout=args.timeout * 2,  # Timeout lebih lama untuk UDP
            protocol='udp',
            show_closed=args.show_closed
        )
        results.update(udp_results)
    
    # Waktu selesai
    end_time = time.time()
    
    # Generate report
    report = generate_scan_report(
        args.host,
        results,
        scan_type=f"{args.protocol.upper()} Connect",
        start_time=start_time,
        end_time=end_time
    )
    
    # Tampilkan summary
    print_summary_report(report)
    
    # Save report jika diminta
    if args.output:
        save_report(report, args.output)
    
    # Export ke CSV jika diminta
    if args.csv:
        export_to_csv(report, args.csv)
    
    # Saran berdasarkan hasil
    open_ports_count = report["scan_info"]["open_ports_count"]
    if open_ports_count == 0:
        print("[+] Tidak ada port terbuka yang ditemukan")
    elif open_ports_count > 10:
        print(f"[!] Warning: {open_ports_count} port terbuka ditemukan")
        print("    Pertimbangkan untuk menutup port yang tidak diperlukan")
    else:
        print(f"[+] Ditemukan {open_ports_count} port terbuka")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[!] Program dihentikan oleh user (Ctrl+C)")
        sys.exit(0)
    except Exception as e:
        print(f"\n[!] Error tidak terduga: {e}")
        if '--verbose' in sys.argv or '-v' in sys.argv:
            import traceback
            traceback.print_exc()
        sys.exit(1)